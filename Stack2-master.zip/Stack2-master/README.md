# magic_box

[![Build Status](https://travis-ci.org/rexxh/Stack2?branch=master)](https://travis-ci.org/rexxh/Stack2)

```bash
tools/build.sh #{PROJECT_NAME}
tools/test.sh
tools/clean.sh
```
