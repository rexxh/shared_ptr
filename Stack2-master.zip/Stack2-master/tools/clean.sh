#!/bin/bash
BUILD_DIR=build
rm -rf $BUILD_DIR
